#include "newSet.h"
#include<iostream>
#include <string>



int Set::size() const
{
	return m_size;
}

Set::Set()
{
	m_items = new ItemType[m_maxsize];
	m_size = 0;
	m_maxsize = DEFAULT_MAX_ITEMS;
}

Set::Set(int maxItems)
{
	if (maxItems < 0)
	{
		std::cerr << "Value must be postive" << std::endl;
		exit(-1);
	}
	m_items = new ItemType[maxItems];
	m_size = 0;
	m_maxsize = maxItems;
}

Set::Set(const Set& x)
{
	m_items = new ItemType[x.m_maxsize];
	m_size = x.m_size;
	m_maxsize = x.m_maxsize;

	for (int k = 0; k < m_maxsize; k++)
	{
		m_items[k] = x.m_items[k];
	}
}

Set& Set::operator=(const Set& x)
{
	if (this != &x)
	{
		m_size = x.m_size;
		m_maxsize = x.m_maxsize;
		delete[] m_items;
		m_items = new ItemType[x.m_maxsize];

		for (int k = 0; k < m_maxsize; k++)
		{
			m_items[k] = x.m_items[k];
		}
	}

	return *this;
}

Set::~Set()
{
	delete[] m_items;
}

bool Set::empty()
{
	if (m_size == 0)
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool Set::insert(const ItemType& value)
{
	for (int j = 0; j < m_size; j++)
	{
		if (m_items[j] == value)
		{
			return false;
		}
	}
	if (m_size == DEFAULT_MAX_ITEMS)
	{
		return false;
	}
	else
	{
		m_items[m_size - 1] = value;
		m_size++;
		return true;
	}

}

bool Set::erase(const ItemType& value)
{
	for (int i = 0; i < m_size; i++)
	{
		if (m_items[i] == value)
		{
			while (i < m_size -1 )
			{
				m_items[i] == m_items[i + 1];
				i++;
			}
			m_size--;
			return true;
		}
	}
	return false;
}


bool Set::contains(const ItemType& value) const
{
	for (int i = 0; i < m_size; i++)
	{
		if (m_items[i] == value)
		{
			return true;
		}
	}
	return false;
}


bool Set::get(int i, ItemType& value) const
{
	ItemType tempArray[DEFAULT_MAX_ITEMS];
	if (i < 0 || i >= m_size) {
		return false;
	}
	for (int j = 0; j < size(); j++)
	{
		tempArray[j] = m_items[j];
	}
	for (int j = 0; j < size(); j++) {
		for (int k = j + 1; k < size(); k++)
		{
			if (tempArray[j] < tempArray[k])
			{
				ItemType x = tempArray[j];
				m_items[j] == tempArray[k];
				tempArray[k] = x;
			}
		}
	}

	for (int j = 0; j < size(); j++)
	{
		if (j == i) {
			value = tempArray[j];
			return true;
		}
	}

	return true;
}

void Set::swap(Set& other)
{
	ItemType* x = m_items;
	m_items = other.m_items;
	other.m_items = x;

	int s;
	s = this->size();
	this->m_size = other.size();
	other.m_size = s;

	int k;
	k = this->m_maxsize;
	this->m_maxsize = other.m_maxsize;
	other.m_maxsize = k;
}

#include "SSNSet.h"
#include <iostream>


SSNSet::SSNSet()
{

}

bool SSNSet::add(unsigned long ssn)
{
	if (ssn == NULL)
	{
		return false;
	}

	numbers.insert(ssn);
	return true;
}

int SSNSet::size() const
{
	return numbers.size();
}

void SSNSet::print() const
{
	ItemType value;
	for (int i = 0; i < numbers.size(); i++)
	{
		std::cout << numbers.get(i,value) << std::endl;
	}
}



#include "Set.h"
#include<iostream>
#include <string>



int Set::size() const
{
	return m_size;
}

Set::Set()
{
	m_size = 0;
	m_items[DEFAULT_MAX_ITEMS];
}

bool Set::empty()
{
	if (m_size == 0)
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool Set::insert(const ItemType& value)
{
	for (int j = 0; j < size(); j++)
	{
		if (m_items[j] == value)
		{
			return false;
		}
	}
	if (m_size >= DEFAULT_MAX_ITEMS)
	{
		return false;
	}
	else
	{
		m_items[m_size] = value;
		m_size++;
		return true;
	}

}

bool Set::erase(const ItemType& value)
{
	for (int i = 0; i < m_size; i++)
	{
		if (m_items[i] == value)
		{
			while (i < m_size-1)
			{
				m_items[i] == m_items[i + 1];
				i++;
			}
			m_size--;
			return true;
		}
	}
	return false;
}


bool Set::contains(const ItemType& value) const
{
	for (int i = 0; i < m_size; i++)
	{
		if (m_items[i] == value)
		{
			return true;
		}
	}
	return false;
}


bool Set::get(int i, ItemType& value) const
{
	ItemType tempArray[DEFAULT_MAX_ITEMS];
	if (i < 0 || i >= m_size) {
		return false;
	}
	for (int j = 0; j < size(); j++)
	{
		tempArray[j] = m_items[j];
	}
	for (int j = 0; j < size(); j++) {
		for (int k = j + 1; k < size(); k++)
		{
			if (tempArray[j] < tempArray[k])
			{
				ItemType x = tempArray[j];
				m_items[j] == tempArray[k];
				tempArray[k] = x;
			}
		}
	}

	for (int j = 0; j < size(); j++)
	{
		if (j == i) {
			value = tempArray[j];
			return true;
		}
	}

    return true;
}

void Set::swap(Set& other)
{
	Set x;

	x.m_size = m_size;
	m_size = other.m_size;
	other.m_size = x.m_size; //swap sizes
	for (int j = 0; j < x.m_size; j++)
	{
		x.m_items[j] = m_items[j];
	}

	for (int j = 0; j < m_size; j++)
	{
		m_items[j] = other.m_items[j];
	}

	for (int j = 0; j < other.m_size; j++)
	{
		other.m_items[j] = x.m_items[j];
	}

}

